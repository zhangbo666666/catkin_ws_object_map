# mf_estimation
K.Joo, T.-H Oh, J.Kim, I.S. Kweon, "globally optimal Manhattan frame estimation in real-time", CVPR 2016

Source code:
  MATLAB implementation
  (dependency: mapping toolbox)

